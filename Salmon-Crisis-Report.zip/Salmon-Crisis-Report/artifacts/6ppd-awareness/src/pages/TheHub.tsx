import { useState } from "react";
import { motion } from "framer-motion";
import { Link } from "wouter";
import { Download, ExternalLink, Check } from "lucide-react";
import { Button } from "@/components/ui/button";

const fadeUp = {
  hidden: { opacity: 0, y: 20 },
  visible: (delay = 0) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.4, delay, ease: "easeOut" as const },
  }),
};

const resources = [
  {
    title: "2026 Technical Report",
    subtitle: "6PPD-Quinone in Urban Watersheds: A Comprehensive Assessment",
    desc: "Released May 2026. 47 pages.",
  },
  {
    title: "Species Sensitivity Dataset",
    subtitle: "Raw LC50 data covering 12 species across 3 study groups",
    desc: "CSV format, peer-reviewed",
  },
  {
    title: "BC Policy Statement",
    subtitle: "February 2026 Water Quality Guidelines: 6PPD-Q Classification Document",
    desc: "Official Policy Document",
  },
];

const actions = [
  {
    number: "01",
    heading: "Write to Your Representative",
    body: "Contact your MP, MLA, or Senator and ask them to support stronger tire antioxidant regulations and stormwater monitoring requirements in urban salmon watersheds. A single letter from a constituent carries real weight.",
    cta: "Find your representative",
    href: "https://www.ourcommons.ca/members/en",
    color: "teal",
  },
  {
    number: "02",
    heading: "Share This Site",
    body: "Most people have never heard of 6PPD-Quinone. Paste the link in a group chat, post it to social media, or send it to a journalist or teacher. Awareness is the first lever that moves policy.",
    cta: "Copy link",
    href: "#share",
    color: "teal",
  },
  {
    number: "03",
    heading: "Support Bioswale Infrastructure",
    body: "Ask your municipality to include bioswales and rain gardens in road and parking lot projects. These structures intercept stormwater before it reaches creeks, and they work. Contact your city councillor or show up to a public hearing.",
    cta: "BC green infrastructure resources",
    href: "https://www2.gov.bc.ca/gov/content/environment/air-land-water/water",
    color: "teal",
  },
  {
    number: "04",
    heading: "Back First Nations Fisheries Monitoring",
    body: "Cowichan Tribes, Squamish Nation, and other Indigenous nations have been monitoring salmon habitat long before researchers arrived. Donate to or publicly support their programs. They are tracking the problem in real time.",
    cta: "Cowichan Stewardship",
    href: "https://cowichantribes.com",
    color: "teal",
  },
  {
    number: "05",
    heading: "Demand Greener Tires",
    body: "6PPD has safer alternatives. Write to tire manufacturers like Bridgestone, Michelin, and Continental and ask when they plan to transition. Consumer pressure has changed tire chemistry before.",
    cta: "Learn about HPPD alternatives",
    href: "https://www.fisheries.noaa.gov/feature-story/tire-chemical-killing-coho-salmon",
    color: "red",
  },
];

export default function TheHub() {
  const [copied, setCopied] = useState(false);

  const copyLink = () => {
    navigator.clipboard.writeText(window.location.origin).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  return (
    <div className="flex flex-col min-h-screen bg-white px-4 md:px-8 lg:px-16 py-12 max-w-7xl mx-auto w-full">
      <motion.header
        variants={fadeUp}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true }}
        className="mb-16"
      >
        <h1 className="text-4xl md:text-5xl font-bold text-primary mb-4">The Hub</h1>
        <p className="text-xl text-slate-500">Research library and concrete actions you can take today.</p>
      </motion.header>

      {/* Research Library */}
      <section className="mb-20">
        <motion.h2
          variants={fadeUp}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="text-2xl font-bold text-slate-900 mb-8"
        >
          Research Library
        </motion.h2>
        <div className="space-y-4">
          {resources.map((res, i) => (
            <motion.div
              key={i}
              variants={fadeUp}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: "-40px" }}
              custom={i * 0.1}
              className="bg-white border border-slate-200 rounded-xl p-6 flex flex-col sm:flex-row gap-6 justify-between items-start sm:items-center shadow-sm hover:shadow-md transition-shadow"
            >
              <div>
                <span className="inline-block px-2 py-1 bg-teal-50 text-primary text-xs font-mono rounded mb-3 border border-teal-100">
                  {res.title}
                </span>
                <h3 className="text-base font-bold text-slate-900 mb-2">{res.subtitle}</h3>
                <p className="text-sm text-slate-400">{res.desc}</p>
              </div>
              <Button
                variant="outline"
                className="border-primary text-primary hover:bg-primary hover:text-white whitespace-nowrap shadow-none shrink-0"
              >
                <Download className="mr-2 h-4 w-4" /> Download
              </Button>
            </motion.div>
          ))}
        </div>
      </section>

      {/* What You Can Do */}
      <section className="mb-16">
        <motion.div
          variants={fadeUp}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="mb-10"
        >
          <h2 className="text-2xl font-bold text-slate-900 mb-3">What You Can Do</h2>
          <p className="text-slate-500 max-w-2xl">
            The science is settled. What's missing is public pressure. Any one of these five actions moves the needle.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {actions.map((action, i) => (
            <motion.div
              key={i}
              variants={fadeUp}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: "-40px" }}
              custom={i * 0.1}
              className="bg-white border border-slate-200 rounded-xl p-6 flex flex-col shadow-sm hover:shadow-md transition-shadow"
            >
              <div
                className={`text-4xl font-black font-mono mb-4 ${
                  action.color === "red" ? "text-red-100" : "text-teal-100"
                }`}
              >
                {action.number}
              </div>
              <h3 className="text-lg font-bold text-slate-900 mb-3">{action.heading}</h3>
              <p className="text-sm text-slate-500 leading-relaxed flex-1 mb-5">{action.body}</p>
              {action.href === "#share" ? (
                <button
                  onClick={copyLink}
                  className="inline-flex items-center gap-1.5 text-sm font-semibold text-primary hover:text-primary/80 transition-colors"
                >
                  {copied ? (
                    <><Check className="w-3.5 h-3.5" /> Copied!</>
                  ) : (
                    action.cta
                  )}
                </button>
              ) : (
                <a
                  href={action.href}
                  target={action.href.startsWith("http") ? "_blank" : undefined}
                  rel="noopener noreferrer"
                  className={`inline-flex items-center gap-1.5 text-sm font-semibold transition-colors ${
                    action.color === "red"
                      ? "text-red-600 hover:text-red-700"
                      : "text-primary hover:text-primary/80"
                  }`}
                >
                  {action.cta}
                  {action.href.startsWith("http") && <ExternalLink className="w-3.5 h-3.5" />}
                </a>
              )}
            </motion.div>
          ))}
        </div>
      </section>

      <div className="w-full py-6 text-center border-t border-slate-100 mt-auto">
        <Link href="/" className="text-sm text-slate-400 hover:text-primary transition-colors">
          Return to Command Center →
        </Link>
      </div>
    </div>
  );
}
