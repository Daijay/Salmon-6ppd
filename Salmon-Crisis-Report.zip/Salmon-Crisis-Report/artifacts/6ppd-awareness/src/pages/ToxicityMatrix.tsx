import { motion } from "framer-motion";
import { Link } from "wouter";
import { ComposedChart, Area, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ReferenceLine, ResponsiveContainer } from 'recharts';

const TEAL = "#0D9488";
const RED  = "#DC2626";

const fadeUp = {
  hidden: { opacity: 0, y: 20 },
  visible: (delay = 0) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.4, delay, ease: "easeOut" as const },
  }),
};

const speciesData = [
  { species: "Coho Salmon",    lc50: 0.095, rating: "EXTREME",  status: "Critically Affected" },
  { species: "Brook Trout",    lc50: 0.59,  rating: "HIGH",     status: "Significantly Affected" },
  { species: "Rainbow Trout",  lc50: 1.00,  rating: "MODERATE", status: "Affected at High Conc." },
  { species: "Chinook Salmon", lc50: 2.5,   rating: "LOW",      status: "Tolerant" },
  { species: "Steelhead",      lc50: 0.8,   rating: "HIGH",     status: "Threshold Species" },
];

const stormData = [
  { time: '0h',   waterLevel: 0.2,  concentration: 0.08 },
  { time: '0.5h', waterLevel: 0.6,  concentration: 0.15 },
  { time: '1h',   waterLevel: 1.0,  concentration: 0.95 },
  { time: '1.5h', waterLevel: 1.2,  concentration: 1.38 },
  { time: '2h',   waterLevel: 1.3,  concentration: 1.42 },
  { time: '3h',   waterLevel: 1.1,  concentration: 1.10 },
  { time: '4h',   waterLevel: 0.9,  concentration: 0.75 },
  { time: '6h',   waterLevel: 0.7,  concentration: 0.52 },
  { time: '8h',   waterLevel: 0.5,  concentration: 0.38 },
  { time: '12h',  waterLevel: 0.4,  concentration: 0.25 },
  { time: '24h',  waterLevel: 0.3,  concentration: 0.12 },
  { time: '48h',  waterLevel: 0.25, concentration: 0.08 },
];

const getBadgeColor = (rating: string) => {
  switch (rating) {
    case "EXTREME":  return "bg-red-600 text-white";
    case "HIGH":     return "bg-orange-500 text-white";
    case "MODERATE": return "bg-yellow-400 text-slate-900";
    case "LOW":      return "bg-green-500 text-white";
    default:         return "bg-slate-400 text-white";
  }
};

export default function ToxicityMatrix() {
  return (
    <div className="flex flex-col min-h-screen bg-white px-4 md:px-8 lg:px-16 py-10 max-w-7xl mx-auto w-full">
      <motion.header
        variants={fadeUp}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true }}
        className="mb-10 md:mb-16"
      >
        <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold text-primary mb-3">Toxicity Matrix</h1>
        <p className="text-base sm:text-xl text-slate-500 leading-relaxed">
          Comparative species sensitivity to 6PPD-Quinone, based on LC50 data from 24-hour exposures.
        </p>
      </motion.header>

      {/* PHOTO — salmon leaping */}
      <motion.div
        variants={fadeUp}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, margin: "-40px" }}
        className="relative overflow-hidden rounded-xl mb-12 h-52 sm:h-72 shadow-sm"
      >
        <img
          src="/img/salmon_jump.jpg"
          alt="Coho salmon leaping upstream through rushing water"
          className="w-full h-full object-cover object-center"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent" />
        <p className="absolute bottom-3 left-4 text-white/80 text-[11px] font-mono tracking-wide">
          Coho salmon leaping upstream, a journey ended by 6PPD-Q contamination
        </p>
      </motion.div>

      {/* Species Table */}
      <motion.section
        variants={fadeUp}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, margin: "-40px" }}
        className="mb-12"
      >
        <div className="overflow-x-auto bg-white border border-slate-200 rounded-xl shadow-sm">
          <table className="w-full text-left border-collapse min-w-[320px]">
            <thead>
              <tr className="border-b border-slate-200 text-xs font-semibold text-slate-500 bg-slate-50">
                <th className="p-3 sm:p-4">Species</th>
                <th className="p-3 sm:p-4">LC50</th>
                <th className="p-3 sm:p-4">Rating</th>
                <th className="p-3 sm:p-4 hidden sm:table-cell">Status</th>
                <th className="p-3 sm:p-4 hidden md:table-cell w-1/3">Threshold</th>
              </tr>
            </thead>
            <tbody>
              {speciesData.map((row, i) => (
                <tr key={i} className="border-b border-slate-100 hover:bg-slate-50 transition-colors">
                  <td className="p-3 sm:p-4 font-semibold text-slate-900 text-sm">{row.species}</td>
                  <td className="p-3 sm:p-4 font-mono text-primary text-sm">
                    {row.lc50}{row.species === "Chinook Salmon" ? "+" : ""} µg/L
                  </td>
                  <td className="p-3 sm:p-4">
                    <span className={`px-2 py-0.5 rounded-full text-[10px] sm:text-xs font-bold tracking-wider ${getBadgeColor(row.rating)}`}>
                      {row.rating}
                    </span>
                  </td>
                  <td className="p-3 sm:p-4 text-xs text-slate-500 hidden sm:table-cell">{row.status}</td>
                  <td className="p-3 sm:p-4 hidden md:table-cell">
                    <div className="relative w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                      <div className="absolute top-0 bottom-0 w-0.5 bg-red-500 z-10" style={{ left: `${(0.8 / 2.5) * 100}%` }} />
                      <motion.div
                        initial={{ width: 0 }}
                        whileInView={{ width: `${Math.min((row.lc50 / 2.5) * 100, 100)}%` }}
                        viewport={{ once: true }}
                        transition={{ duration: 0.8, delay: i * 0.08 }}
                        className="h-full bg-primary/50 rounded-full"
                      />
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </motion.section>

      {/* Mitochondrial Mechanism */}
      <motion.section
        variants={fadeUp}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, margin: "-40px" }}
        className="mb-12"
      >
        <div className="bg-white border border-slate-200 border-l-4 border-l-primary rounded-xl p-5 md:p-8 shadow-sm">
          <h2 className="text-xl sm:text-2xl font-bold text-slate-900 mb-3">How It Kills: Mitochondrial Dysfunction</h2>
          <p className="text-sm sm:text-base text-slate-500 mb-6 leading-relaxed">
            6PPD-Q disrupts the electron transport chain in fish mitochondria, cutting off cellular ATP production. The fish suffocate at the cellular level: they simply cannot generate enough energy to breathe, move, or survive. Pre-spawn adult Coho are especially vulnerable because their metabolic demand peaks during upstream migration.
          </p>
          <div className="flex flex-col md:flex-row items-center justify-between gap-3">
            <div className="bg-teal-50 border border-teal-200 rounded-lg p-4 flex-1 text-center w-full">
              <span className="text-primary font-semibold text-sm">6PPD-Q Enters Cell</span>
            </div>
            <div className="text-slate-300 text-lg hidden md:block">→</div>
            <div className="text-slate-300 text-lg md:hidden">↓</div>
            <div className="bg-orange-50 border border-orange-200 rounded-lg p-4 flex-1 text-center w-full">
              <span className="text-orange-600 font-semibold text-sm">Mitochondria Disrupted</span>
            </div>
            <div className="text-slate-300 text-lg hidden md:block">→</div>
            <div className="text-slate-300 text-lg md:hidden">↓</div>
            <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex-1 text-center w-full">
              <span className="text-red-600 font-semibold text-sm">ATP Production Fails</span>
            </div>
          </div>
        </div>
      </motion.section>

      {/* Storm Pulse Chart */}
      <motion.section
        variants={fadeUp}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, margin: "-40px" }}
        className="mb-12"
      >
        <div className="bg-white border border-slate-200 rounded-xl p-4 sm:p-6 shadow-sm">
          <h2 className="text-lg sm:text-2xl font-bold text-slate-900 mb-1">
            The Storm Pulse: Concentration During a Rain Event
          </h2>
          <p className="text-slate-400 mb-6 text-xs sm:text-sm">
            Yorkson Creek, Langley BC. Simulated first-flush event.
          </p>
          <div className="w-full h-[260px] sm:h-[340px] md:h-[400px]">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={stormData} margin={{ top: 20, right: 10, bottom: 10, left: -10 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,0,0,0.06)" vertical={false} />
                <XAxis
                  dataKey="time"
                  stroke="#CBD5E1"
                  tick={{ fill: '#94A3B8', fontSize: 11 }}
                  interval="preserveStartEnd"
                />
                <YAxis
                  yAxisId="left"
                  stroke="#CBD5E1"
                  tick={{ fill: '#94A3B8', fontSize: 11 }}
                  width={38}
                />
                <YAxis
                  yAxisId="right"
                  orientation="right"
                  stroke="#CBD5E1"
                  tick={{ fill: '#94A3B8', fontSize: 11 }}
                  width={32}
                />
                <Tooltip
                  contentStyle={{ backgroundColor: '#fff', borderColor: '#E2E8F0', color: '#0F172A', fontSize: 12, borderRadius: 8 }}
                  itemStyle={{ color: '#0F172A' }}
                />
                <Legend wrapperStyle={{ paddingTop: '16px', fontSize: 12, color: '#64748B' }} />
                <ReferenceLine
                  y={0.8}
                  yAxisId="left"
                  stroke={RED}
                  strokeDasharray="4 3"
                  label={{ position: 'insideTopRight', value: '⚠ 0.8 µg/L', fill: RED, fontSize: 11 }}
                />
                <Area
                  yAxisId="right"
                  type="monotone"
                  dataKey="waterLevel"
                  name="Water Level"
                  fill="#BAE6FD"
                  fillOpacity={0.4}
                  stroke="none"
                />
                <Line
                  yAxisId="left"
                  type="monotone"
                  dataKey="concentration"
                  name="6PPD-Q (µg/L)"
                  stroke={TEAL}
                  strokeWidth={2.5}
                  dot={false}
                  activeDot={{ r: 5 }}
                />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
        </div>
      </motion.section>

      <div className="w-full py-5 text-center border-t border-slate-100 mt-auto">
        <Link href="/response" className="text-sm text-slate-400 hover:text-primary transition-colors">
          Next: Global Response →
        </Link>
      </div>
    </div>
  );
}
