import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";

const TOTAL_SIM_SECS = 48 * 3600;
const TICK_MS = 200;
const SIM_SECS_PER_TICK = 1200;

const TEAL = "#0D9488";
const RED  = "#DC2626";

const fadeUp = {
  hidden: { opacity: 0, y: 20 },
  visible: (delay = 0) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.4, delay, ease: "easeOut" as const },
  }),
};

export default function CommandCenter() {
  const [, setLocation] = useLocation();
  const [simSecs, setSimSecs] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setSimSecs((s) => {
        const next = s + SIM_SECS_PER_TICK;
        return next >= TOTAL_SIM_SECS ? 0 : next;
      });
    }, TICK_MS);
    return () => clearInterval(interval);
  }, []);

  const hh = Math.floor(simSecs / 3600).toString().padStart(2, "0");
  const mm = Math.floor((simSecs % 3600) / 60).toString().padStart(2, "0");
  const ss = (simSecs % 60).toString().padStart(2, "0");
  const progressPct = (simSecs / TOTAL_SIM_SECS) * 100;
  const isPastLC50 = simSecs >= 24 * 3600;

  const milestones = [
    { hour: 4,  label: "Respiratory Distress",  simSec: 4  * 3600 },
    { hour: 24, label: "50% Mortality",          simSec: 24 * 3600 },
    { hour: 48, label: "Population Collapse",    simSec: 48 * 3600 },
  ];

  const activeMilestone = milestones.filter((m) => simSecs >= m.simSec).pop();

  return (
    <div className="flex flex-col min-h-screen bg-white">
      {/* HERO */}
      <section className="relative w-full min-h-[70dvh] md:h-[calc(100dvh-64px)] flex flex-col justify-center items-center text-center px-5 py-16 md:py-0 overflow-hidden bg-slate-50">
        <div
          className="absolute inset-0 z-0 opacity-[0.06] pointer-events-none"
          style={{
            backgroundImage: "radial-gradient(circle at center, #0D9488 1px, transparent 1px)",
            backgroundSize: "36px 36px",
          }}
        />
        <div className="z-10 w-full max-w-4xl space-y-5">
          <motion.div
            initial={{ opacity: 0, y: -16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-primary font-mono text-[10px] sm:text-xs tracking-widest font-semibold"
          >
            6PPD-QUINONE GLOBAL AWARENESS PORTAL
          </motion.div>
          <motion.h1
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.15 }}
            className="text-[2.1rem] leading-tight sm:text-5xl md:text-7xl font-bold tracking-tight text-slate-900"
          >
            0.8 µg/L: The Chemical Red Line.
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.28 }}
            className="text-sm sm:text-lg md:text-xl text-slate-500 max-w-2xl mx-auto leading-relaxed"
          >
            A single rainstorm can deliver a lethal dose to Coho salmon within hours of first rainfall. Here is the data.
          </motion.p>
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, delay: 0.42 }}
            className="pt-6 flex flex-col sm:flex-row gap-3 justify-center"
          >
            <Button
              size="lg"
              className="w-full sm:w-auto bg-primary text-white hover:bg-primary/90 font-semibold px-8 py-5 text-base rounded-none shadow-sm"
              onClick={() => setLocation("/science")}
              data-testid="hero-primary-cta"
            >
              Enter the Research Vault
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="w-full sm:w-auto border-slate-300 text-slate-700 hover:bg-slate-100 font-semibold px-8 py-5 text-base rounded-none"
              onClick={() => setLocation("/response")}
              data-testid="hero-secondary-cta"
            >
              View Global Response
            </Button>
          </motion.div>
        </div>
      </section>

      {/* PHOTO STRIP — BC salmon run */}
      <div className="w-full relative overflow-hidden h-56 sm:h-72 md:h-96">
        <img
          src="/img/salmon1.jpg"
          alt="Coho salmon running through a British Columbia river during autumn spawning season"
          className="w-full h-full object-cover object-center"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent" />
        <p className="absolute bottom-3 left-4 text-white/80 text-[11px] font-mono tracking-wide">
          Coho salmon running in a BC river, autumn spawning season
        </p>
      </div>

      {/* BENTO GRID */}
      <section className="px-4 md:px-8 lg:px-16 py-12 max-w-7xl mx-auto w-full">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6">

          {/* Card A: The Molecule */}
          <motion.div
            variants={fadeUp}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-40px" }}
            custom={0}
            className="bg-white border border-slate-200 rounded-xl p-5 md:row-span-2 flex flex-col items-center text-center shadow-sm"
          >
            <h3 className="text-lg font-bold text-primary mb-1">6PPD-Quinone</h3>
            <div className="text-xs font-mono text-slate-400 mb-4">C₁₈H₂₂N₂O</div>
            <div className="flex-1 flex items-center justify-center min-h-[160px] w-full">
              <svg viewBox="0 0 200 200" className="w-full max-w-[160px] md:max-w-[200px]">
                <line x1="100" y1="140" x2="100" y2="180" stroke="#CBD5E1" strokeWidth="4" />
                <line x1="100" y1="180" x2="130" y2="200" stroke="#CBD5E1" strokeWidth="4" />
                <line x1="100" y1="180" x2="70"  y2="200" stroke="#CBD5E1" strokeWidth="4" />
                <polygon points="100,50 130,70 130,110 100,130 70,110 70,70" fill="none" stroke="#94A3B8" strokeWidth="4" />
                <line x1="75"  y1="75" x2="75"  y2="105" stroke="#CBD5E1" strokeWidth="2" />
                <line x1="125" y1="75" x2="125" y2="105" stroke="#CBD5E1" strokeWidth="2" />
                <line x1="100" y1="50" x2="100" y2="20"  stroke="#CBD5E1" strokeWidth="4" />
                <line x1="100" y1="20" x2="130" y2="0"   stroke="#CBD5E1" strokeWidth="4" />
                <line x1="100" y1="20" x2="70"  y2="0"   stroke="#CBD5E1" strokeWidth="4" />
                <circle cx="100" cy="140" r="10" fill={TEAL} />
                <circle cx="100" cy="40"  r="10" fill={RED}  />
              </svg>
            </div>
            <p className="text-xs text-slate-500 mt-4 text-left leading-relaxed">
              Derived from 6PPD tire antioxidant via ozone oxidation
            </p>
          </motion.div>

          {/* Card B: Storm Cycle Clock */}
          <motion.div
            variants={fadeUp}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-40px" }}
            custom={0.08}
            className="bg-white border border-slate-200 rounded-xl p-5 md:col-span-2 flex flex-col shadow-sm"
          >
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-base sm:text-lg font-bold text-red-600">48-Hour Storm Cycle</h3>
              <span className="text-[10px] font-mono text-slate-400 bg-slate-100 px-2 py-1 rounded">
                DEMONSTRATION
              </span>
            </div>

            <div
              className="text-[2.6rem] sm:text-5xl md:text-6xl font-mono font-bold tabular-nums tracking-tighter mb-3 transition-colors duration-700"
              style={{ color: isPastLC50 ? RED : TEAL }}
            >
              {hh}:{mm}:{ss}
            </div>

            <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden mb-1.5 relative">
              <div className="absolute top-0 bottom-0 w-px bg-slate-300" style={{ left: `${(4 / 48) * 100}%` }} />
              <div className="absolute top-0 bottom-0 w-px bg-slate-400" style={{ left: "50%" }} />
              <div
                className="h-full rounded-full transition-all duration-200"
                style={{
                  width: `${progressPct}%`,
                  background: isPastLC50
                    ? `linear-gradient(90deg, ${TEAL} 0%, ${RED} 50%, ${RED} 100%)`
                    : TEAL,
                }}
              />
            </div>
            <div className="flex justify-between text-[10px] text-slate-400 mb-4">
              <span>0h</span>
              <span className="text-orange-500">4h</span>
              <span className="text-red-500 font-bold">24h LC50</span>
              <span>48h</span>
            </div>

            <div className="grid grid-cols-3 gap-1.5 sm:gap-2 mb-3">
              {milestones.map((m) => {
                const reached  = simSecs >= m.simSec;
                const isActive = activeMilestone?.hour === m.hour;
                return (
                  <div
                    key={m.hour}
                    className={`rounded-lg py-2.5 px-2 border text-center transition-all duration-500 ${
                      isActive
                        ? "border-red-400 bg-red-50"
                        : reached
                        ? "border-slate-300 bg-slate-50"
                        : "border-slate-100 bg-transparent opacity-50"
                    }`}
                  >
                    <div className={`text-sm sm:text-base font-bold font-mono mb-0.5 ${
                      isActive ? "text-red-600" : reached ? "text-slate-700" : "text-slate-400"
                    }`}>
                      {m.hour}h
                    </div>
                    <div className="text-[10px] sm:text-xs text-slate-500 leading-tight">{m.label}</div>
                  </div>
                );
              })}
            </div>

            {activeMilestone && (
              <motion.div
                key={activeMilestone.hour}
                initial={{ opacity: 0, y: 4 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-[11px] font-mono text-red-600 border border-red-200 bg-red-50 rounded px-3 py-2"
              >
                ⚠ ACTIVE: {activeMilestone.label}
              </motion.div>
            )}
          </motion.div>

          {/* Card C: The Source */}
          <motion.div
            variants={fadeUp}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-40px" }}
            custom={0.16}
            className="bg-white border border-slate-200 rounded-xl p-5 relative overflow-hidden flex flex-col shadow-sm"
          >
            <h3 className="text-base font-bold text-slate-900 mb-3">Origin: Tire Wear</h3>
            <div className="flex-1 flex justify-center items-center py-6 relative min-h-[120px]">
              <div className="w-28 h-20 bg-slate-100 rounded-lg border-2 border-slate-200 flex flex-col justify-evenly p-2 z-10 relative">
                <div className="w-full h-1.5 bg-slate-300 rounded-sm"></div>
                <div className="w-full h-1.5 bg-slate-300 rounded-sm"></div>
                <div className="w-full h-1.5 bg-slate-300 rounded-sm"></div>
                <div className="w-full h-1.5 bg-slate-300 rounded-sm"></div>
              </div>
              <div className="absolute inset-0 flex justify-center overflow-hidden z-0">
                <motion.div
                  animate={{ y: [0, 80], opacity: [0, 1, 0] }}
                  transition={{ repeat: Infinity, duration: 2.2, ease: "linear" }}
                  className="w-2 h-2 rounded-full bg-primary absolute top-8"
                />
                <motion.div
                  animate={{ y: [0, 80], opacity: [0, 1, 0] }}
                  transition={{ repeat: Infinity, duration: 2.8, delay: 0.7, ease: "linear" }}
                  className="w-2 h-2 rounded-full bg-primary absolute top-8 ml-10"
                />
                <motion.div
                  animate={{ y: [0, 80], opacity: [0, 1, 0] }}
                  transition={{ repeat: Infinity, duration: 2.0, delay: 1.2, ease: "linear" }}
                  className="w-2 h-2 rounded-full bg-primary absolute top-8 mr-10"
                />
              </div>
            </div>
            <p className="text-xs text-slate-500 mt-3 leading-relaxed">
              6PPD is added to every tire to prevent dry rot. At highway speeds, 0.005g/km of rubber is shed per tire.
            </p>
          </motion.div>

          {/* Card D: Storm Pulse */}
          <motion.div
            variants={fadeUp}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-40px" }}
            custom={0.24}
            className="bg-white border border-slate-200 rounded-xl p-5 md:col-span-2 flex flex-col shadow-sm"
          >
            <h3 className="text-base font-bold text-slate-900 mb-4">The Storm Pulse Effect</h3>
            <div className="flex-1 relative w-full h-36 sm:h-48 bg-slate-50 rounded-lg p-3 border border-slate-100">
              <svg viewBox="0 0 500 150" className="w-full h-full overflow-visible" preserveAspectRatio="none">
                <line x1="0" y1="120" x2="500" y2="120" stroke="rgba(0,0,0,0.06)" strokeWidth="1" />
                <line x1="0" y1="80"  x2="500" y2="80"  stroke="rgba(0,0,0,0.06)" strokeWidth="1" />
                <line x1="0" y1="40"  x2="500" y2="40"  stroke="rgba(0,0,0,0.06)" strokeWidth="1" />
                <line x1="0" y1="60"  x2="500" y2="60"  stroke={RED} strokeWidth="1.5" strokeDasharray="5,4" />
                <path
                  d="M 0 130 C 50 130, 80 130, 100 20 C 150 100, 250 110, 500 120"
                  fill="none"
                  stroke={TEAL}
                  strokeWidth="3"
                />
                <text x="4"   y="145" fill="rgba(0,0,0,0.35)" fontSize="10">0h</text>
                <text x="96"  y="145" fill="rgba(0,0,0,0.35)" fontSize="10">1h</text>
                <text x="200" y="145" fill="rgba(0,0,0,0.35)" fontSize="10">2h</text>
                <text x="300" y="145" fill="rgba(0,0,0,0.35)" fontSize="10">4h</text>
                <text x="400" y="145" fill="rgba(0,0,0,0.35)" fontSize="10">8h</text>
                <text x="466" y="145" fill="rgba(0,0,0,0.35)" fontSize="10">16h</text>
                <text x="106" y="16"  fill={TEAL} fontSize="11" fontWeight="bold">1.4 µg/L</text>
                <text x="420" y="55"  fill={RED}  fontSize="10">0.8 µg/L</text>
              </svg>
            </div>
            <p className="text-xs text-slate-500 mt-3 border-l-2 border-primary pl-3 leading-relaxed">
              Concentrations peak in the first flush. That opening wave of runoff carries the highest chemical load, which is exactly why real-time creek monitoring matters.
            </p>
          </motion.div>
        </div>
      </section>

      {/* CTA FOOTER */}
      <motion.section
        variants={fadeUp}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, margin: "-40px" }}
        className="w-full bg-slate-50 border-t border-slate-200 py-14 px-4 text-center mt-auto"
      >
        <h2 className="text-xl sm:text-2xl md:text-3xl font-bold text-slate-900 mb-5">Ready to go deeper?</h2>
        <Button
          size="lg"
          className="w-full sm:w-auto bg-primary text-white hover:bg-primary/90 font-bold px-8 shadow-sm"
          onClick={() => setLocation("/science")}
          data-testid="footer-cta-vault"
        >
          Enter the Research Vault →
        </Button>
      </motion.section>

      <div className="w-full py-5 text-center border-t border-slate-100">
        <Link href="/science" className="text-sm text-slate-400 hover:text-primary transition-colors">
          Next: Toxicity Matrix →
        </Link>
      </div>
    </div>
  );
}
