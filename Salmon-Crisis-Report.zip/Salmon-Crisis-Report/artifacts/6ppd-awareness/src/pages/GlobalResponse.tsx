import { motion } from "framer-motion";
import { Link } from "wouter";

const fadeUp = {
  hidden: { opacity: 0, y: 20 },
  visible: (delay = 0) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.4, delay, ease: "easeOut" as const },
  }),
};

const timelineEvents = [
  {
    date: "February 2026",
    title: "British Columbia Water Quality Guidelines Updated",
    desc: "BC Ministry of Environment issued a Policy Statement classifying 6PPD-Q as a priority toxic substance, mandating monitoring in all urban salmon-bearing watersheds.",
  },
  {
    date: "April 2026",
    title: "Strickland-Merkley Federal Bill Introduced (US)",
    desc: "The 'Safer Tires for Safer Waters Act' (introduced April 2026) directs the EPA to identify 6PPD-safe tire alternatives and fund a $50M research program for bio-compatible antioxidant substitutes.",
  },
  {
    date: "May 2026",
    title: "EPA Task Force Established",
    desc: "US EPA formed the 6PPD-Q Urban Runoff Task Force, bringing together tire manufacturers, watershed scientists, and Indigenous fisheries stakeholders.",
  },
];

const strategies = [
  {
    title: "Bio-Engineering",
    subtitle: "Rain Gardens & Bioswales",
    desc: "Bioswales placed at key runoff points capture the first flush and let natural soil filtration break down 6PPD-Q before it reaches any waterway. Cost-effective and scalable.",
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-8 h-8 text-primary">
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7z" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 2v10" />
      </svg>
    ),
  },
  {
    title: "Active Filtration",
    subtitle: "Modular Filtration Units",
    desc: "Deployable in-line filtration units placed at storm drain outfalls. Part of the R.I.V.E.R. Framework, these units remove up to 94% of 6PPD-Q before it reaches the waterway.",
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-8 h-8 text-primary">
        <rect x="4" y="4" width="16" height="16" rx="2" />
        <path d="M4 10h16" />
        <path d="M10 4v16" />
      </svg>
    ),
  },
  {
    title: "Real-Time Monitoring",
    subtitle: "Sensor Network Deployment",
    desc: "A $42,000 sensor network reads 6PPD-Q levels at key creeks every 15 minutes. Continuous data means communities get early warning before concentrations turn lethal.",
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-8 h-8 text-primary">
        <path d="M12 2v20" />
        <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6" />
      </svg>
    ),
  },
];

const stakeholders = [
  { name: "EPA",            full: "Environmental Protection Agency", role: "Federal Oversight" },
  { name: "VIU",            full: "Vancouver Island University",     role: "Academic Research" },
  { name: "Cowichan Tribes",full: "",                                role: "First Nations Fisheries Monitoring" },
  { name: "Squamish Nation",full: "",                                role: "Traditional Territory Stewardship" },
  { name: "Metro Vancouver",full: "",                                role: "Urban Watershed Management" },
  { name: "NOAA Fisheries", full: "",                                role: "Species Conservation" },
];

export default function GlobalResponse() {
  return (
    <div className="flex flex-col min-h-screen bg-white px-4 md:px-8 lg:px-16 py-12 max-w-7xl mx-auto w-full">
      <motion.header
        variants={fadeUp}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true }}
        className="mb-16"
      >
        <h1 className="text-4xl md:text-5xl font-bold text-primary mb-4">Global Response</h1>
        <p className="text-xl text-slate-500">
          Regulatory updates, mitigation strategies, and active stakeholders as of May 2026.
        </p>
      </motion.header>

      {/* Legislative Timeline */}
      <section className="mb-20">
        <motion.h2
          variants={fadeUp}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="text-2xl font-bold text-slate-900 mb-8"
        >
          2026 Legislative Updates
        </motion.h2>
        <div className="relative border-l-2 border-primary pl-8 space-y-8 ml-4">
          {timelineEvents.map((event, i) => (
            <motion.div
              key={i}
              variants={fadeUp}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: "-40px" }}
              custom={i * 0.12}
              className="relative"
            >
              <div className="absolute -left-[41px] top-1 w-4 h-4 rounded-full bg-primary ring-4 ring-white" />
              <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm">
                <span className="text-sm font-mono text-primary mb-2 block">{event.date}</span>
                <h3 className="text-xl font-bold text-slate-900 mb-3">{event.title}</h3>
                <p className="text-slate-500 leading-relaxed">{event.desc}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Mitigation Strategies */}
      <section className="mb-20">
        <motion.h2
          variants={fadeUp}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="text-2xl font-bold text-slate-900 mb-8"
        >
          Mitigation Strategies
        </motion.h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {strategies.map((strategy, i) => (
            <motion.div
              key={i}
              variants={fadeUp}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: "-40px" }}
              custom={i * 0.12}
              className="bg-white border border-slate-200 rounded-xl p-6 flex flex-col shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="mb-4 bg-teal-50 p-4 rounded-lg inline-block w-fit">{strategy.icon}</div>
              <h3 className="text-lg font-bold text-slate-900 mb-1">{strategy.title}</h3>
              <h4 className="text-sm font-medium text-primary mb-4">{strategy.subtitle}</h4>
              <p className="text-sm text-slate-500 flex-1">{strategy.desc}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* PHOTO — BC watershed */}
      <motion.div
        variants={fadeUp}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, margin: "-40px" }}
        className="relative overflow-hidden rounded-xl mb-20 h-52 sm:h-72 shadow-sm"
      >
        <img
          src="/img/creek.jpg"
          alt="A forested British Columbia creek and waterfall, habitat at risk from stormwater runoff"
          className="w-full h-full object-cover object-center"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/55 via-transparent to-transparent" />
        <p className="absolute bottom-3 left-4 text-white/80 text-[11px] font-mono tracking-wide">
          A BC watershed stream, at risk from first-flush stormwater runoff events
        </p>
      </motion.div>

      {/* Stakeholders */}
      <section className="mb-16">
        <motion.h2
          variants={fadeUp}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="text-2xl font-bold text-slate-900 mb-8"
        >
          Active Stakeholders
        </motion.h2>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 md:gap-6">
          {stakeholders.map((org, i) => (
            <motion.div
              key={i}
              variants={fadeUp}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: "-40px" }}
              custom={i * 0.08}
              className="bg-white border border-slate-200 rounded-xl p-6 flex flex-col justify-center text-center shadow-sm hover:shadow-md transition-shadow"
            >
              <h3 className="text-2xl font-bold text-primary mb-2">{org.name}</h3>
              {org.full && <p className="text-xs text-slate-400 mb-2">{org.full}</p>}
              <p className="text-sm text-slate-500 mt-auto pt-4 border-t border-slate-100">{org.role}</p>
            </motion.div>
          ))}
        </div>
      </section>

      <div className="w-full py-6 text-center border-t border-slate-100 mt-auto">
        <Link href="/hub" className="text-sm text-slate-400 hover:text-primary transition-colors">
          Next: The Hub →
        </Link>
      </div>
    </div>
  );
}
