import { Link, useLocation } from "wouter";

export function Nav() {
  const [location] = useLocation();

  const links = [
    { href: "/",         label: "Command Center",  short: "Home"     },
    { href: "/science",  label: "Toxicity Matrix", short: "Science"  },
    { href: "/response", label: "Global Response", short: "Response" },
    { href: "/hub",      label: "The Hub",         short: "Hub"      },
  ];

  return (
    <nav className="sticky top-0 z-50 w-full bg-white/95 backdrop-blur-md border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 md:px-8 lg:px-16 flex items-center justify-between h-14 sm:h-16 gap-3">
        <Link
          href="/"
          className="font-mono text-primary font-bold tracking-widest text-base shrink-0"
          data-testid="nav-logo"
        >
          6PPD-Q
        </Link>

        {/* Links — always visible */}
        <div className="flex items-center gap-1 sm:gap-6 lg:gap-8 overflow-x-auto no-scrollbar">
          {links.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className={`shrink-0 text-[11px] sm:text-sm font-medium transition-colors whitespace-nowrap px-1.5 sm:px-0 py-1 ${
                location === link.href
                  ? "text-primary border-b-2 border-primary"
                  : "text-slate-500 hover:text-slate-900"
              }`}
              data-testid={`nav-link-${link.label.replace(/\s+/g, '-').toLowerCase()}`}
            >
              <span className="sm:hidden">{link.short}</span>
              <span className="hidden sm:inline">{link.label}</span>
            </Link>
          ))}
        </div>
      </div>
    </nav>
  );
}
