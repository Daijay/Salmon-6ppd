import { Switch, Route, Router as WouterRouter, useLocation } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { useEffect } from "react";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Nav } from "@/components/Nav";
import { ScrollToTopButton } from "@/components/ScrollToTopButton";

import CommandCenter from "@/pages/CommandCenter";
import ToxicityMatrix from "@/pages/ToxicityMatrix";
import GlobalResponse from "@/pages/GlobalResponse";
import TheHub from "@/pages/TheHub";
import NotFound from "@/pages/not-found";

const queryClient = new QueryClient();

function ScrollToTop() {
  const [location] = useLocation();
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "instant" });
  }, [location]);
  return null;
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={CommandCenter} />
      <Route path="/science" component={ToxicityMatrix} />
      <Route path="/response" component={GlobalResponse} />
      <Route path="/hub" component={TheHub} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <div className="min-h-screen bg-background text-foreground flex flex-col">
            <ScrollToTop />
            <Nav />
            <ScrollToTopButton />
            <main className="flex-1 flex flex-col">
              <Router />
            </main>
          </div>
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
